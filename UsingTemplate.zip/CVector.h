
//  Created by Wei-Hsuan Lien on 2018/5/17.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.


#ifndef CVector_h
#define CVector_h

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

template<class T>
class CVector 
{
//    friend ostream &operator<<(ostream&, const CVector&);
    
public:
    
    CVector(); 
    // Constructs an empty container for character, with a length of zero characters. 
    // *default capacity = 10
    
    CVector( const CVector&); 
    // Constructs a copy of "vec". (copy constructor)
    
    ~CVector(); 
    // Destroys this container object.
    
    //char* begin(); 
    // Returns an pointer referring to the first character in this container.
    
    //char* end(); 
    // Returns an pointer referring to the past-the-end character of this container.
    // The past-the-end character is a theoretical character that would follow the last character in the container.
    // It shall not be dereferenced.
    
    size_t getSize() const; 
    // Returns the number of characters in this container (vector).
    
    void resize( size_t n, char c = '\0' ); 
    // Resizes the string to a length of n characters.
    // If n is smaller than the current string length,
    // the current value is shortened to its first n character and remove the characters beyond the nth character.
    // If n is greater than the current string length,
    // the current content is extended by inserting at the end as many characters as needed to reach a size of n.
    // The new elements are initialized by character c.
    
    size_t getCapacity() const; 
    // NOTE: default capacity = 10
    // Returns the size of the storage space currently allocated for this container,
    // expressed in terms of elements.
    // *This capacity is not necessarily equal to the string length. It can be equal or greater, 
    // with the extra space allowing the object to optimize its operations when new characters are added to the string.
    
    void reserve( size_t n = 0 ); 
    // Requests that the capacity to be enough to contain n characters.
    // If n is greater than the current string capacity,
    // the function causes the container to reallocate its storage increasing its capacity to n.
    // Otherwise, the function call does NOT cause a reallocation. (the string capacity is not affected)
    
    void shrink_to_fit(); 
    // Requests the container to reduce its "capacity" to fit its "size".
    
    void clear(); 
    // Erases the contents of the string, which becomes an empty string 
    // (with a length of 0 characters, the Capacity is not affected).
    
    bool empty() const; 
    // Returns whether the string is empty (i.e. whether its size is 0).
    
    char &front(); 
    // *Returns a reference to the first character of the string.
    // This function shall not be called on empty strings.
    
    char &back(); 
    // *Returns a reference to the last character of the string.
    // This function shall not be called on empty strings.
    
    void push_back( char); 
    // Appends character c to the end of the string, increasing its length by one.
    // *Return the reference of itself
    
    void pop_back(); 
    // Erases the last character of the string, effectively reducing its size by one. 
    // (the string capacity is not affected)
    // *Return the reference of itself
    
    char& operator[] (size_t); //Get character of this string
    char operator[] (size_t) const;
    // Value with the position of a character within the string.
    // Note: The first character in a string is denoted by a value of 0 (not 1).
    // size_t is an unsigned integral type (the same as member type string::size_type).
    
    bool operator==(const CVector &) const; ///< (equal to) true: two identical String
    bool operator!=(const CVector &) const; ///< (not equal to)
    //Compares the value of the string object to the sequence of characters specified by its arguments.
    
private:
    size_t Size; 
    // the number of elements in the string
    // This is the number of actual objects held in the string, which is not necessarily equal to its storage capacity.
    
    size_t Capacity; 
    // the size of the storage space currently allocated for the string, expressed in terms of elements.
    // This capacity is not necessarily equal to the string size. It can be equal or greater,
    // with the extra space allowing to accommodate for growth without the need to reallocate on each insertion.
    
    char *str; 
    // points to a dynamically allocated array which is used to store the elements of the string
    
}; // end class String

//template<class T> 
//ostream& operator<<(ostream& output, const CVector<T>& sttt)
//{
//    for (size_t i = 0; i < sttt.Size; i++){
//        output << sttt[i];
//    }
//    return output;
//}

template<class T> CVector<T>::CVector(){
    Capacity = 10;
    Size = 0;
    str = new T [Capacity];
    for (size_t i = 0; i < Capacity; i++)
        str[i] = '\0';
}

template<class T> CVector<T>::CVector(const CVector<T>& copy)
{
    str = new T [copy.Capacity];
    for (size_t i = 0; i < copy.Capacity; i++)
        str[i] = '\0';
    for (int i = 0; i < copy.Size; i++)
        str[i] = copy.str[i];
    
    Size = copy.Size;
    Capacity = copy.Capacity;
}

template<class T> CVector<T>::~CVector()
{
    delete[] str;
}

template<class T>size_t CVector<T>::getSize() const
{
    return Size;
}

template<class T>void CVector<T>::resize(size_t reSize, char word)
{
    if (reSize >= Capacity-1){
        while (Size >= Capacity-1){
            Capacity *= 10;
            if (Capacity < reSize)
                Capacity = reSize;
            T *temp = new T [Capacity];
            for (int i = 0; i < Size; i++)
                temp[i] = str[i];
            
            T *move = new T [Capacity];
            for (int i = 0; i < Size; i++)
                move[i] = temp[i];
            
            delete [] str;
            str = new T[Capacity];
            for (int i = 0; i < Capacity; i++)
                str[i] = word;
            for (int i = 0; i < Size; i++)
                str[i] = move[i];
            
            delete [] temp;
            delete [] move;
        }
        Size = reSize;
    }
    else
        Size = reSize;
}

template<class T>size_t CVector<T>::getCapacity() const
{
    return Capacity;
}

template<class T>void CVector<T>::reserve(size_t newCapacity)
{
    Capacity = newCapacity;
    CVector temp;
    for (int i = 0; i < Capacity; i++)
        temp.str[i] = str[i];
    delete[] str;
    str = new T[Capacity];
    for (int i = 0; i < Capacity; i++)
        str[i] = '\0';
    for (int i = 0; i < Capacity; i++)
        str[i] = temp.str[i];
}

template<class T>void CVector<T>::shrink_to_fit()
{
    Capacity = Size;
    CVector temp;
    for (int i = 0; i < Capacity; i++)
        temp.str[i] = str[i];
    delete[] str;
    str = new T[Capacity];
    for (int i = 0; i < Capacity; i++)
        str[i] = '\0';
    for (int i = 0; i < Capacity; i++)
        str[i] = temp.str[i];
}

template<class T>void CVector<T>::clear()
{
    delete[] str;
    str = new T [Capacity];
    for (size_t i = 0; i < Capacity; i++)
        str[i] = '\0';
    Size = 0;
}

template<class T>bool CVector<T>::empty() const
{
    if (Size == 0)
        return 1;
    else 
        return 0;
}

template<class T>char& CVector<T>::front()
{
    return str[0];
}

template<class T>char& CVector<T>::back()
{
    return str[Size-1];
}

template<class T>void CVector<T>::push_back(char push)
{
    if (Size >= Capacity-1)
        resize(Size);
    
    for (size_t i = Size; i < (Size+1); i++){
        str[i] = push;
    }
    Size++;
}

template<class T>void CVector<T>::pop_back()
{
    char *tempstr = new T [Capacity];
    for (size_t i = 0; i < Capacity; i++)
        tempstr[i] = '\0';
    
    for (size_t i = 0; i < Size-1; i++)
        tempstr[i] = str[i];
    
    delete []str;
    Size--;
    resize(Size);
    str = new T [Capacity];
    for (size_t i = 0; i < Capacity; i++)
        str[i] = '\0';
    for (size_t i = 0; i < Size; i++){
        str[i] = tempstr[i];
    }
}

template<class T>char& CVector<T>::operator[] (size_t num)
{
    return str[num];
}

template<class T>char CVector<T>::operator[](size_t num) const
{
    return str[num];
}

template<class T>bool CVector<T>::operator==(const CVector<T>& findstr) const
{
    size_t i = 0;
    int a = 0, b = 0;
    if (Size == findstr.Size){
        for (i = 0; i < Size; i++){
            a++;
            if (str[i] == findstr.str[i]){
                b++;
                if (a == b)
                    return 1;
            }
        }
    }
    else
        return 0;
    
    return 0;
}

template<class T>bool CVector<T>::operator!=(const CVector& findstr) const
{
    size_t i = 0;
    int a = 0, b = 0;
    if (Size != findstr.Size)
        return 1;
    
    else if (Size == findstr.Size){
        for (i = 0; i < Size; i++){
            a++;
            if (str[i] != findstr.str[i])
                return 1;
            else{
                b++;
                if (a == b)
                    return 0;
            }
        }
    }
    return 0;
}
//

#endif /* s1042701_CVector_hpp */

